public interface LiquidFuel {
    public abstract double getRange();
    public abstract int getEmissionTier();
}
