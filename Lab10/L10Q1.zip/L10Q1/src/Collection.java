public interface Collection {
    void add(Object obj);
    void remove(Object obj);
    Boolean contain(Object obj);
    Boolean isEmpty();
    int size();
}
